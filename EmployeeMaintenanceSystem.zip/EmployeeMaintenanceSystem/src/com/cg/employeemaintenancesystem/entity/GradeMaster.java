package com.cg.employeemaintenancesystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="grade_master")
public class GradeMaster {

	public GradeMaster() {
		// TODO Auto-generated constructor stub
	}
	@Id
	@Column(name="Grade_Code")
	private String GradeCode;
	@Column(name="Description")
	private String Description;
	@Column(name="Min_Salary")
	private Double minSalary;
	@Column(name="Max_Salary")
	private Double maxSalary;
	
	
	public String getGradeCode() {
		return GradeCode;
	}
	public void setGradeCode(String gradeCode) {
		GradeCode = gradeCode;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Double getMinSalary() {
		return minSalary;
	}
	public void setMinSalary(Double minSalary) {
		this.minSalary = minSalary;
	}
	public Double getMaxSalary() {
		return maxSalary;
	}
	public void setMaxSalary(Double maxSalary) {
		this.maxSalary = maxSalary;
	}	
}
